package exceptions;

public class CpfJaUtilizadoException extends Exception {
	
	private static final long serialVersionUID = -5773216499211640574L;

	public CpfJaUtilizadoException(String mensagem) {
		super(mensagem);
	}
}