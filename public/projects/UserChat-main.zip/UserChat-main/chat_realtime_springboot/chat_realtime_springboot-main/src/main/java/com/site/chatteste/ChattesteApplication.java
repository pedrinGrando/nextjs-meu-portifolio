package com.site.chatteste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChattesteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChattesteApplication.class, args);
	}
}
