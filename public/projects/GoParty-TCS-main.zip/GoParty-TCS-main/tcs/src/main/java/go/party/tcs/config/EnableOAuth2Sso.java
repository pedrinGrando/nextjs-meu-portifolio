package go.party.tcs.config;

public @interface EnableOAuth2Sso {

}
