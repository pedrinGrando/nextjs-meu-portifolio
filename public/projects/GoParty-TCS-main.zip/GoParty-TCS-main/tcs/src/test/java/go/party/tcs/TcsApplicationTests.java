package go.party.tcs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TcsApplicationTests {

	@Test
	void contextLoads() {
	}

}
